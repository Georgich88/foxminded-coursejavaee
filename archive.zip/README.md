# CourseJavaEE

This GitLab repository hosts the code for the tasks from Java EE Foxminded course.

![logo](https://foxminded.com.ua/wp-content/uploads/2018/02/logo_2f.png?1 "Foxminded")

Description
-----------

Tasks for following topics:
* Clean Code
* SQL
* Decomposition And Application Architecture
* Domain Layer
* User Interface
* Application Transformation
* Services