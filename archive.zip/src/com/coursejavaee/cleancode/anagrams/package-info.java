/*
 * Copyright (c) 2019 Georgich88
 * This program is made available under the terms of the MIT License.
 */

/**
 * Anagrams solver (task 1)
 * Foxminded Java EE course.
 */

/**
 * @author Georgy Isaev
 * @version 1.02 2019-08-07
 */
package com.coursejavaee.cleancode.anagrams;